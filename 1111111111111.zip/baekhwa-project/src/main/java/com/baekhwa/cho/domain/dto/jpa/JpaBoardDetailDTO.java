package com.baekhwa.cho.domain.dto.jpa;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import com.baekhwa.cho.domain.entity.JpaBoardEntity;

import lombok.Getter;


@Getter
public class JpaBoardDetailDTO {
	
	private long no;
	private String title;
	private String content;
	private String writer;
	private int readCount;
	private LocalDateTime createdDate;
	private LocalDateTime updatedDate;
	//private List<ReplyListDTO> replies;
	
	public JpaBoardDetailDTO(JpaBoardEntity e) {
		this.no = e.getNo();
		this.title = e.getTitle();
		this.content = e.getContent();
		this.writer = e.getWriter();
		this.readCount = e.getReadCount();
		this.createdDate = e.getCreatedDate();
		this.updatedDate = e.getUpdatedDate();
		//댓글 entity로 read 결과를 dto로 mapping처리
		//System.out.println(">>>>>>>>>reply entity -> dto");
		//replies=e.getReplies().stream().map(ReplyListDTO::new).collect(Collectors.toList());
	}
	
	

}
