package com.baekhwa.cho.domain.entity;

import java.util.List;
import java.util.Vector;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

/*@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Entity*/
public class Category2 {
	/*
	 * @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private long
	 * categoryNo;
	 * 
	 * @Column(nullable = false) private String name;
	 * 
	 * @ManyToMany(mappedBy = "categorys")
	 * 
	 * @Builder.Default List<Item> items = new Vector<Item>();
	 */
}
