package com.baekhwa.cho.domain.entity;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Entity
public class CategoryItem {
	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	private long categoryItemNo;
	
	@JoinColumn(name = "categoryNo")
	@ManyToOne
	private Category category;

	@JoinColumn(name = "itemNo")
	@ManyToOne(cascade = CascadeType.ALL)
	private Item item;
}