package com.baekhwa.cho.domain.entity;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Vector;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.baekhwa.cho.domain.dto.jpa.JpaBoardUpdateDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;



@Builder
@AllArgsConstructor
@NoArgsConstructor//No default constructor for entity: db에서 결과를 매핑을 위해서 필요합니다.
@Getter
@EntityListeners(AuditingEntityListener.class)
@Entity
public class JpaBoardEntity {//jpa_board_entity
	

	@GeneratedValue(strategy = GenerationType.IDENTITY)//auto_increment
	@Id
	private long no;
	
	@Column(nullable = false)//not null
	private String title;
	@Column(columnDefinition = "text not null") //text : oracle-CLOB
	private String content;
	@Column(nullable = false)
	private String writer;
	private int readCount;
	
	@CreationTimestamp // @EnableJpaAuditing 같은거 안 해줘도 
	private LocalDateTime createdDate;
	
	@UpdateTimestamp  // @EnableJpaAuditing 같은거 안 해줘도 
	private LocalDateTime updatedDate;
	
	//@EnableJpaAuditing :->  @CreatedDate @LastModifiedDate
	
	
	@Builder.Default
	@OneToMany(mappedBy ="jpaBoardEntity"  ,cascade = CascadeType.ALL)
	private Collection<ReplyEntity> replies=new Vector<ReplyEntity>();
	//replies 등록 메서드
	public JpaBoardEntity addReply(ReplyEntity e) {
		replies.add(e);
		return this;
	}
	
	
	//수정처리 하기 위한 메서드
	public JpaBoardEntity update(JpaBoardUpdateDTO dto) {
		this.title=dto.getTitle();
		this.content=dto.getContent();
		return this;
	}

}
