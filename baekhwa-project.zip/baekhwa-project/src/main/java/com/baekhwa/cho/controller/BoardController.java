package com.baekhwa.cho.controller;

import javax.servlet.http.HttpSession;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.filter.HiddenHttpMethodFilter;

import com.baekhwa.cho.domain.dto.BoardInsertDTO;
import com.baekhwa.cho.domain.dto.BoardUpdateDTO;
import com.baekhwa.cho.domain.dto.LoginDTO;
import com.baekhwa.cho.service.BoardService;
import com.baekhwa.cho.service.impl.BoardServiceProc;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class BoardController {
	
	@Autowired
	private BoardService service;
	
	//데이터베이스 정보 읽어와서 리스트 페이지 이동
	@GetMapping("/board")
	public String list(@RequestParam(defaultValue = "1") int pageNo, Model model) {
		//db에서 데이터 읽어올꼐요...모델
		//페이지에 전달
		
		//service.boardListAll(model);
		service.boardList(pageNo, model);
		return "view/board/list";
	}
	//writer page move
	@GetMapping("/board/write")
	public String write(HttpSession session) {
		LoginDTO loginfo=(LoginDTO)session.getAttribute("loginfo");
		
		if(loginfo==null) {
			//로그인이 되지 않은경우에는 이동불가
			return "redirect:/signin";
		}
		return "view/board/write"; //페이지 정보
	}
	//글쓰기 입력 처리
	
	@PostMapping("/board/write")
	public String write(BoardInsertDTO dto) {
		log.debug(">>>>"+dto);
		service.save(dto);
		return "redirect:/board"; //단지이동 "view/board/list"(x)
	}
	//detail page process
	@GetMapping("/board/{bno}") // "/board/detail?no=3?"
	public String detail(@PathVariable("bno") int no, Model model) {
		System.out.println("no: "+no);
		//what?
		//use no then select db data
		service.detail(no, model);
		//???page + detail-data
		return "view/board/detail";
	}
	
	@PostMapping("/board/{no}")
	public String update(/* @PathVariable("no") int no,*/ BoardUpdateDTO dto) {
		service.update(dto);
		//System.out.println(dto);
		
		return "redirect:/board/"+dto.getNo(); //
		
	}
	
	//application.properties에서 hiddenmethod.filter =true
	//설정해야 사용가능
	
	@ResponseBody
	@DeleteMapping("/board/{no}") // "/board/detail?no=3?"
	public void detail(@PathVariable int no) {
//		System.out.println("delete_no:: " +no);
		
		service.delete(no);
	}
}
