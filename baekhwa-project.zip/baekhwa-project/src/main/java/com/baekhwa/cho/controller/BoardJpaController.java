package com.baekhwa.cho.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.baekhwa.cho.domain.dto.jpa.JpaBoardInsertDTO;
import com.baekhwa.cho.domain.dto.jpa.JpaBoardUpdateDTO;
import com.baekhwa.cho.domain.dto.jpa.ReplyInsertDTO;
import com.baekhwa.cho.service.BoardJpaService;

@Controller
public class BoardJpaController {
	
	@Autowired
	private BoardJpaService service;
	
	//jpa 게시판으로 이동 ---화면에 list가 나와야해요
	@GetMapping("/boardjpa")
	public String list(Model model, @RequestParam(defaultValue = "1") int pageNo) {
		//데이터 갖고가야죠:Model객체를 통해서 view에 데이터 전달
		//페이지 이동
		service.list(pageNo, model);
		return "view/boardjpa/list";
	}
	
	//jpa게시판 글쓰기 페이지 이동
	@GetMapping("/boardjpa/write")
	public String write() {
		return "view/boardjpa/write";
	}
	
//	@PostMapping("/boardjpa/write")
//	public String write(HttpServletRequest request) {//request 파라미터 data(post: form-data) (get:queryString parameter)
//		String title=request.getParameter("title");
//		String cotent=request.getParameter("content");
//		String writer=request.getParameter("writer");
//		JpaBoardInsertDTO dto = new JpaBoardInsertDTO(title, content, writer);
//		return "";
//	}
	
//	@PostMapping("/boardjpa/write")
//	public String write(String title, String content, String writer) {//request 파라미터 data(post: form-data) (get:queryString parameter)
//		return "";
//	} 결국엔 여기있는데이터 service에 넘길거야 그래서 dto로 한번에 받아서 넘겨준다. 자동매핑된다.
	
	//글쓰기 버튼 클릭했을때 db에 저장
	@PostMapping("/boardjpa/write")
	public String write(JpaBoardInsertDTO dto) {//request 파라미터 data(post: form-data) (get:queryString parameter)
//		System.out.println(dto); controller는 사용자가 진입하는 진입점이야 바빠 할일이 많아 그러니까 subcontroller인 service한테 넘기고 service가 db를 필요로할때 그때 db 연결하면 돼 
		service.save(dto);
		return "redirect:/boardjpa";
	}
	
	// /boardjpa/2 , /boardjpa/1
	@GetMapping("/boardjpa/{no}")
	public String detail (@PathVariable long no , Model model) {
		service.detail(no ,model);
		return "view/boardjpa/detail";
	}
	@PutMapping("/boardjpa/{no}")
	public String update(@PathVariable long no, JpaBoardUpdateDTO dto) {
//		System.out.println(dto);
		service.update(no, dto);
		return "redirect:/boardjpa/"+no;
	}
	
	@ResponseBody
	@DeleteMapping("/boardjpa/{no}")
	public void delete(@PathVariable long no) {
		service.delete(no);
	}
	
	@ResponseBody
	@PostMapping("/boardjpa/{bno}/reply")
	public boolean reply(ReplyInsertDTO dto) {
		return service.reply(dto);
	}
	
	//상세페이지에서 페이지로딩후 댓글 읽어오기
	@GetMapping("/boardjpa/{bno}/replies")
	public String replies(@PathVariable long bno, Model model) {
		return service.replies(bno, model);
	}
}
