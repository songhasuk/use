package com.baekhwa.cho.domain.dto;

import lombok.Builder;
import lombok.Setter;
import lombok.ToString;

@Builder
@ToString
@Setter
public class BoardInsertDTO {
	
	private String title;
	private String content;
	private String writer;
}
