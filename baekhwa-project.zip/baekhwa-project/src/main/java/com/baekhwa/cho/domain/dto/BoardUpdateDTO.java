package com.baekhwa.cho.domain.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@ToString
@Setter
public class BoardUpdateDTO {
	
	int no;
	String title;
	String content;
	
}
