package com.baekhwa.cho.domain.dto.jpa;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import com.baekhwa.cho.domain.entity.JpaBoardEntity;
import com.baekhwa.cho.domain.entity.ReplyEntity;

import lombok.Getter;


@Getter
public class JpaBoardListDto {
	
	private long no;
	private String title;
	private String writer;
	private int readCount;
	private LocalDateTime updatedDate;
	
	
//	이런방식도 있다 method참조 형식. 그치만 복잡함 그냥 생성자 참조 형식 쓰자
//	public static JpaBoardListDto toJpaBoardListDto(JpaBoardEntity e) {
//		no=e.getNo();
//		title=e.getTitle();
//		writer=e.getWriter();
//		readCount=e.getReadCount();
//		updatedDate=e.getUpdatedDate();
//		return this;
//	}
	
	//생성자
	public JpaBoardListDto(JpaBoardEntity e) {
		no=e.getNo();
		title=e.getTitle();
		writer=e.getWriter();
		readCount=e.getReadCount();
		updatedDate=e.getUpdatedDate();
		}
}
