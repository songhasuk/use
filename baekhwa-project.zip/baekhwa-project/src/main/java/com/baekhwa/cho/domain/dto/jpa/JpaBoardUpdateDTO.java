package com.baekhwa.cho.domain.dto.jpa;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Setter
@Getter
public class JpaBoardUpdateDTO {
	
//	long no;
	String title;
	String content;
}
