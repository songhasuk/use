package com.baekhwa.cho.domain.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.baekhwa.cho.domain.dto.jpa.JpaBoardInsertDTO;
											//Crud말고 더많은 기능쓰려고 JpaRepository..//<엔티티클래스이름, pk에 해당하는 컬럼의 dataType generic에는 무조건 Long, Integer(wrapper class)>
@Repository
public interface JpaBoardEntityRepository extends JpaRepository<JpaBoardEntity, Long> {


}
