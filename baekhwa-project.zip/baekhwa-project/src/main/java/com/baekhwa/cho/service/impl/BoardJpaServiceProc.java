package com.baekhwa.cho.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.Vector;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.mariadb.jdbc.client.impl.ReplayClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

import com.baekhwa.cho.domain.dto.jpa.JpaBoardDetailDTO;
import com.baekhwa.cho.domain.dto.jpa.JpaBoardInsertDTO;
import com.baekhwa.cho.domain.dto.jpa.JpaBoardListDto;
import com.baekhwa.cho.domain.dto.jpa.JpaBoardUpdateDTO;
import com.baekhwa.cho.domain.dto.jpa.ReplyInsertDTO;
import com.baekhwa.cho.domain.dto.jpa.ReplyListDTO;
import com.baekhwa.cho.domain.entity.JpaBoardEntity;
import com.baekhwa.cho.domain.entity.JpaBoardEntityRepository;
import com.baekhwa.cho.domain.entity.ReplyEntity;
import com.baekhwa.cho.domain.entity.ReplyEntityRepository;
import com.baekhwa.cho.service.BoardJpaService;
import com.baekhwa.cho.util.PageInfo;
@Service
public class BoardJpaServiceProc implements BoardJpaService {
	//추상메서드를 인터페이스에 만들어 놨는데 구현 클래스에 오버라이드하지 않아서
	
	//jap dao: repository
	@Autowired
	JpaBoardEntityRepository repository;
	
	@Override
	public void save(JpaBoardInsertDTO dto) {
		
		//저장 Entity
		repository.save(dto.toEntity());
	}

	@Override
	public void list(int pageNo, Model model) {//request scope과 동일: Model -> view 까지 전달
//		repository.findAll().forEach(System.out::println); //entity요소를 하나씩 가져와서 나열할수있는 stream //entity를 매핑하는거 map
		
		/*
		List<JpaBoardListDto> result = repository.findAll()//List<JpaBoardEntity>
												.stream()//Stream<JpaBoardEntity>
												//.map(e->{return new JpaBoardListDto(e);})
												.map(JpaBoardListDto::new)
												.collect(Collectors.toList());
		model.addAttribute("list", result);
		*/
		int page = pageNo-1; //zero-based page index
		int size=10; //the size of th epage to be returned
		Sort sort = Sort.by(Direction.DESC, "no");
		Pageable pageable=PageRequest.of(page, size, sort);
		
		//repository.findAll(pageable).stream().map(JpaBoardListDto::new).collect(Collectors.toList());
		Page<JpaBoardEntity> pageObj = repository.findAll(pageable);
		int pageTotal = pageObj.getTotalPages();
		System.out.println(">>>>>>>>>>");
		PageInfo pageInfo=PageInfo.getInstance(pageNo, pageTotal);
		
		model.addAttribute("pi",pageInfo);
		model.addAttribute("list",pageObj.getContent().stream().map(JpaBoardListDto::new).collect(Collectors.toList()));
		
		/*
		//jsp에선 이렇게 했었음
		//위코드와 동일한 표현 java 1.8보다 하위버전..
		List<JpaBoardEntity> r = repository.findAll();
		List<JpaBoardListDto> list = new Vector<>();
		for(JpaBoardEntity e:r) {
			JpaBoardListDto dto= new JpaBoardListDto(e);
			list.add(dto);
		}
		model.addAttribute("list",list);
		*/
		
		/* 서버에서-> 페이지(view)로 넘길때는 Entity -> DTO로 패핑하여 페이지로... */
	}

	@Override
	public void detail(long no, Model model) {
		/*
		Optional<JpaBoardDetailDTO> result = repository.findById(no).map(new Function<JpaBoardEntity, JpaBoardDetailDTO>() {
			@Override
			public JpaBoardDetailDTO apply(JpaBoardEntity t) {
				return null;
			}
		});
		*/
		
//		Optional<JpaBoardDetailDTO> result = repository.findById(no).map((e)->{return new JpaBoardDetailDTO(e);});
//		Optional<JpaBoardDetailDTO> result = repository.findById(no).map(e->new JpaBoardDetailDTO(e));
//		Optional<JpaBoardDetailDTO> result = repository.findById(no).map(JpaBoardDetailDTO::new);
		//model.addAttribute("detail",result);
		//model.addAttribute("detail",repository.findById(no).map(JpaBoardDetailDTO::new).get());
		/*
		JpaBoardEntity entity = repository.findById(no).orElseThrow();
		JpaBoardDetailDTO dto = new JpaBoardDetailDTO(entity);
		model.addAttribute("detail", dto);
		*/
		JpaBoardEntity entity = repository.findById(no).orElseThrow();
		System.out.println("<<<<쿼리실행");
		model.addAttribute("detail", entity);
	}
	//수정처리
	@Transactional
	@Override           //수정할 대상  //수정할 데이터
	public void update(long no, JpaBoardUpdateDTO dto) {
		
		//@Transactional 적용시
		//repository.findById(no).map(e->{return e.update(dto);});
		repository.findById(no).map(e->e.update(dto));
		
		/*
		//@Transactional 적용 안했을때
		//1.수정할 대상을 확인 PK로 (no) find해라
		JpaBoardEntity entity= repository.findById(no).orElseThrow();
		System.out.println("수정할대상: " +entity);
		//2.수정할 데이터만 변경
		entity.update(dto);
		System.out.println("수정완료: " +entity);
		//3.수정 된 데이터를 저장하면 update가 실행
		repository.save(entity);
		
		//titlecontent만 수정하면 날짜랑 다 null이 된다
		*/
	}

	@Override
	public void delete(long no) {
		repository.deleteById(no);
	}
	
	@Autowired
	private ReplyEntityRepository replyEntityRepository;
	
	@Transactional
	@Override
	public boolean reply(ReplyInsertDTO dto) {
		//댓글저장하려면? 무조건 할거니? 생각좀하자
		//게시글이 잇어야 댓글을 쓸 수 있지
		replyEntityRepository.save(dto.toEntity());
		
			return true;
	}

	 @Override
	   public String replies(long bno, Model model) {
	      List<ReplyListDTO> result= replyEntityRepository.findAllByJpaBoardEntityNo(bno)
	            .stream().map(ReplyListDTO::new).collect(Collectors.toList());
	      model.addAttribute("list",result); //

		return "view/boardjpa/reply/list";
	}
}
