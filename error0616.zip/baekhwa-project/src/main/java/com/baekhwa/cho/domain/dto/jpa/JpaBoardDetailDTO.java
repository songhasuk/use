package com.baekhwa.cho.domain.dto.jpa;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import com.baekhwa.cho.domain.entity.JpaBoardEntity;
import com.baekhwa.cho.domain.entity.ReplyEntity;

import lombok.Getter;


@Getter
public class JpaBoardDetailDTO {
	
	private long no;
	private String title;
	private String content;
	private String writer;
	private int readCount;
	private LocalDateTime createdDate;
	private LocalDateTime updatedDate;
	private List<ReplyListDTO> replies;
	
	public JpaBoardDetailDTO(JpaBoardEntity e) {
		this.no = e.getNo();
		this.title = e.getTitle();
		this.content = e.getContent();
		this.writer = e.getWriter();
		this.readCount = e.getReadCount();
		this.createdDate = e.getCreatedDate();
		this.updatedDate = e.getUpdatedDate();
		replies=e.getReplies().stream().map(ReplyListDTO::new).collect(Collectors.toList());
	}
	
	

}
