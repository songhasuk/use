package com.baekhwa.cho.domain.dto.jpa;

import com.baekhwa.cho.domain.entity.JpaBoardEntity;


import lombok.Setter;
import lombok.ToString;

@ToString
@Setter
public class JpaBoardInsertDTO {
	
	private String title;
	private String content;
	private String writer;
	
	//field data db에 저장할 목적
	//db entity로만 저장해야합니다.
	//dto->entity 매핑이 필요해서 
	//메서드를 만들어서 처리하면 편리해요
	//메서드를 실행해서 entity객체를 얻어오도록 설계
	public JpaBoardEntity toEntity() {
		return JpaBoardEntity.builder()
				.title(title).content(content).writer(writer)				
				.build();
	}
	
	//JpaBoardEntity e1=new JpaBoardEntity(0, title, content, writer, 0, null, null);
	//JpaBoardEntity e2=JpaBoardEntity.builder().build();

}
