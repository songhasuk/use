package com.baekhwa.cho.domain.entity;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor//No default constructor for entity: db에서 결과를 매핑을 위해서 필요합니다.
@Getter
@EntityListeners(AuditingEntityListener.class)
@Entity
public class ReplyEntity {
	@GeneratedValue(strategy = GenerationType.IDENTITY)//auto_increment
	@Id
	private long rno;
	@Column(nullable = false)
	private String text;
	@Column(nullable = false)
	private String replier;
	@CreationTimestamp
	private LocalDateTime createdDate;
	@UpdateTimestamp
	private LocalDateTime updateDate;
	
	
	//private long bno; //게시글의 PK가 들어가야됨
	
	
	@ManyToOne
	JpaBoardEntity board;  //'다'대1 관계
	/*1:1 1:N N:1 N:M*/
	

}
