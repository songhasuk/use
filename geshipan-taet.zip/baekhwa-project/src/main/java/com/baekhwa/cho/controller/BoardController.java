package com.baekhwa.cho.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baekhwa.cho.domain.dto.BoardDTO;
import com.baekhwa.cho.domain.dto.BoardInsertDTO;
import com.baekhwa.cho.domain.dto.BoardUpdateDTO;
import com.baekhwa.cho.domain.dto.LoginDTO;
import com.baekhwa.cho.service.BoardService;
import com.baekhwa.cho.service.impl.BoardServiceProc;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class BoardController {
	
	@Autowired
	private BoardService service;
	
	@GetMapping("/board")
	public String list(@RequestParam(defaultValue = "1") int pageNo, Model model) {
		//db에서 데이터 읽어올꼐요...
		//페이지에 전달
		
		//service.boardListAll(model);	
		
		service.boardList(pageNo, model);
		return "view/board/list";
	}
	
	//글쓰기 페이지 이동 처리
	@GetMapping("/board/write")
	public String write(HttpSession session) {
		
		LoginDTO loginfo =  (LoginDTO) session.getAttribute("loginfo");
		if(loginfo == null) {
			//로그인이 안된 상태에서는 이동불가하게 만들기
			return "redirect:/signin";
		}
		
		return "view/board/write";
	}
	
	//글쓰기 입력 처리
	@PostMapping("/board/write")
	public String write(BoardInsertDTO dto) {
		log.debug(">>>>"+dto);
		
		service.save(dto);
		return "redirect:/board"; 
		//redirect:/board/list로 설정 안한 이유는 
		//redirect:/board/로 먼저 가서 list()메소드가 자동 호출되서 게시물이 출력되야 하니까
		// list()메소드를 출력안하면 게시물을 볼수가 없으니까
	}
	
	
	
	//게시글 상세 페이지 이동 처리
	@GetMapping("/board/{no}")
	public String detail(@PathVariable int no, Model model) {
		//@PathVariable의 dno 값을 no 매개변수에 매핑한다
		System.out.println("no"+no);
		service.detail(no, model); 
		//페이지 넘버로 content 데이터 찾아오고, 그 찾아온 데이터를 model에 저장
		
		
		
		return "view/board/detail";
		
	}
	//계시글 수정 
	@PutMapping("/board/{no}")   //(form 태크 method: post) (input태그 _method : PUT)
	public String update(BoardUpdateDTO dto) {
		service.update(dto);
		return "redirect:/board/"+dto.getNo(); 
		
		//detail()메소드로 가서
	}
	
	//spring.mvc.hiddenmethod.filter.enabled=true\}
	@ResponseBody
	@DeleteMapping("/board/{no}") // _method : DELETE
	public void delete(@PathVariable int no) {
		//System.out.println("delete__no:"+no);
		
		service.delete(no);
		
	}
	

}
