package com.baekhwa.cho.domain.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class BoardUpdateDTO {
	
	private int no;
	private String title;
	private String content;

}
