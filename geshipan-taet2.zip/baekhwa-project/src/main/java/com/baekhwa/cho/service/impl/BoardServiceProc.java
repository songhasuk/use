package com.baekhwa.cho.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.naming.spi.DirStateFactory.Result;

import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.baekhwa.cho.controller.BoardController;
import com.baekhwa.cho.domain.dto.BoardDTO;
import com.baekhwa.cho.domain.dto.BoardInsertDTO;
import com.baekhwa.cho.domain.dto.BoardListDTO;
import com.baekhwa.cho.domain.dto.BoardUpdateDTO;
import com.baekhwa.cho.mybatis.mapper.BoardMapper;
import com.baekhwa.cho.service.BoardService;
import com.baekhwa.cho.util.PageInfo;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class BoardServiceProc implements BoardService {
	
	//dao ???
	@Autowired
	private BoardMapper mapper;
	
	
	
	@Override
	public void boardList(int pageNo, Model model) {
		int limit=10;
		int offset=limit *(pageNo-1);; //현실의 페이지는 offset의 0
		List<BoardListDTO> result = mapper.select(offset,limit);
		int rowTotal = mapper.count();
		
		
		
		
		model.addAttribute("list", result);
		model.addAttribute("pi", PageInfo.getInstance(pageNo, rowTotal, limit));
	
	}
	
	public void boardListAll(Model model) {
		
		//List<BoardDTO> to List<BoardListDTO>
		List<BoardListDTO> result=mapper.findAll()
									.stream()
									.map(BoardListDTO::new)//BoardDTO-->BoardListDTO : BoardListDTO(BoardDTO)
									.collect(Collectors.toList());
		model.addAttribute("list", result);
		
	}

	@Override
	public void save(BoardInsertDTO dto) {
		int n = mapper.save(dto);
		
		
	}

	@Override
	public void detail(int no, Model model) {
		BoardDTO result  = mapper.findById(no).orElseThrow();
		
			model.addAttribute("detail", result);
			
			System.out.println(result);
		
		
		
	}

	@Override
	public void update(BoardUpdateDTO dto) {
		int  n = mapper.update(dto);
		log.debug(null);
		
	}

	@Override
	public void delete(int no) {
		int n = mapper.deleteById(no);
		log.debug(n+"개의 데이터 삭제 완료");
		
	}



	

}
