package ncs12.controller;

import javax.servlet.http.HttpSession;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ncs12.domain.dto.MemberDto;
import ncs12.service.MemberService;


@Controller
@RequestMapping("/mem/*")
public class MemberController {
	
	@Autowired
	private MemberService service; 


	
	@GetMapping("reg")
	public String regPage() {
		return "member/registration"; // templates 경로
	}
	
	@GetMapping("login")
	public String loginPage() {
		return "member/login"; // templates 경로
	}
	@GetMapping("mypage")
	public String mypage(@RequestParam String no, Model model) {
		
		
		return service.list(no, model); // templates 경로
	}
	
	@PostMapping("reg")
	public String join(MemberDto dto, Model model) {
		

		return service.save(dto, model);
	}
	
	@PostMapping("login")
	public String login(MemberDto dto, HttpSession session, Model model) {

		
		return service.logCheck(dto, session, model);
	}
	
	@GetMapping("logout")
	public String logout(HttpSession session) {
		session.invalidate();
		
		return "redirect:/";
	}

	
}
