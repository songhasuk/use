package ncs12.mapper;

import java.util.List;
import java.util.Optional;

import org.apache.ibatis.annotations.Mapper;

import ncs12.domain.dto.MemberDto;

@Mapper
public interface TestMapper {

	void save(MemberDto dto);

	Optional<MemberDto> logCheck(MemberDto dto);

	MemberDto list(String no);



}
