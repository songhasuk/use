package ncs12.service;

import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

import ncs12.domain.dto.MemberDto;

public interface MemberService {

	String save(MemberDto dto, Model model);

	String logCheck(MemberDto dto, HttpSession session, Model model);

	String list(String no, Model model);

}
