package ncs12.service.impl;

import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import ncs12.domain.dto.MemberDto;
import ncs12.mapper.TestMapper;
import ncs12.service.MemberService;

@Service
public class MemberServiceImpl implements MemberService {
	
	@Autowired
	private TestMapper mapper;
	
	@Override
	public String save(MemberDto dto, Model model) {
	
		mapper.save(dto);
		
		model.addAttribute("success", dto.getName()+"님 회원가입 축하합니다");
		
		return "member/login";
	}

	@Override
	public String logCheck(MemberDto dto, HttpSession session, Model model) {
			
		Optional<MemberDto> result = mapper.logCheck(dto);
		
		if(result.isPresent()) {
			MemberDto member = result.get();
			
			if(member.getPw().equals(dto.getPw())) {
				
				session.setAttribute("logInfo", member);
				
				
				return "redirect:/";
			}
		}
		
		model.addAttribute("error", "회원이 아니거나 이미 탈퇴한 회원입니다.");
		return "/member/login";
	}

	@Override
	public String list(String no, Model model) {
		
		MemberDto dto = mapper.list(no);
		System.out.println(dto.toString());
		return "/mem/mypage/"+dto.getNo();
		
	}
	

}
