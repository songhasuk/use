package ncs12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NcsTest12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
