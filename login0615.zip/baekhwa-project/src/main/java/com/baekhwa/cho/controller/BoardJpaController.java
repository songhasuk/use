package com.baekhwa.cho.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.baekhwa.cho.domain.dto.jpa.JpaBoardInsertDTO;
import com.baekhwa.cho.service.BoardJpaService;

@Controller
public class BoardJpaController {
	
	@Autowired
	private BoardJpaService Service;
	
	@GetMapping("/boardjpa")
	public String list(Model model) {
	//model객체 = 서버에서 뷰로 데이터 전달하기 위한 객체	
		
		Service.list(model);
		
		return "view/boardjpa/list";
	}
	@GetMapping("/boardjpa/write")
	public String write() {
		
		return "view/boardjpa/write";
	}
	
	@PostMapping("/boardjpa/write")
	public String write(JpaBoardInsertDTO dto) { //파라미터 매핑도 지원해줘요, 오버로딩
		Service.save(dto);
		return "redirect:/boardjpa";
	}
	
	@GetMapping("/boardjpa/{no}")
	public String detail(@PathVariable long no, Model model) {
		Service.detail(no, model);
		
		return "view/boardjpa/detail";
	}
	
	
	
	

}
