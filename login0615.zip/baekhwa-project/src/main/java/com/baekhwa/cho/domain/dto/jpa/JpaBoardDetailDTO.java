package com.baekhwa.cho.domain.dto.jpa;

import java.time.LocalDateTime;

import com.baekhwa.cho.domain.entity.JpaBoardEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Getter
public class JpaBoardDetailDTO {
	
	private long no;
	private String title;
	private String content;
	private String writer;
	private int readCount;
	private LocalDateTime createdDate;
	private LocalDateTime updatedDate;
	
	public JpaBoardDetailDTO(JpaBoardEntity e) {
		
		this.no = e.getNo();
		this.title = e.getTitle();
		this.content = e.getContent();
		this.writer = e.getWriter();
		this.readCount = e.getReadCount();
		this.createdDate = e.getCreatedDate();
		this.updatedDate = e.getUpdatedDate();
	} 

}
