package com.baekhwa.cho.domain.dto.jpa;

import com.baekhwa.cho.domain.entity.JpaBoardEntity;

import lombok.Builder;
import lombok.Data;
import lombok.ToString;


@ToString
@Data
public class JpaBoardInsertDTO {
	
	private String title;
	private String content;
	private String writer;
	
	
	//필드에 있는 데이터를 DB에 저장할 목적으로 
	//DB ENTITY로만 저장해야되니
	//DTO → ENTITY 매핑이 필요하니
	//이 기능을 하는 메소드를 만들어 처리한다.(메소드를 실행해서 entity객체를 얻어오도록 설계)
	
	public JpaBoardEntity toEntity() {
		
		return  JpaBoardEntity.builder()
				.title(title).content(content).writer(writer).build();
	}

}
