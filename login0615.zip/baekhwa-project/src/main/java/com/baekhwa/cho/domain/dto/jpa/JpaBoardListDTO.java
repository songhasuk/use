package com.baekhwa.cho.domain.dto.jpa;

import java.time.LocalDateTime;

import com.baekhwa.cho.domain.entity.JpaBoardEntity;

import lombok.Getter;


//@setter는 쓸 필요가 없는 이유가. 이미 impl에서 데이터를 저장해서 상관이 없다
@Getter
public class JpaBoardListDTO {
	
	
	private long no;
	private String title;
	private String writer;
	private int readCount;
	private LocalDateTime updatedDate; 
	
	
	//생성자로
	public JpaBoardListDTO(JpaBoardEntity e) { 
		//entity클래서에 저장된 필드값을 dto 필드에 매핑(원본 데이터 안정성 때문에 카피본 만들기)
		no=e.getNo();
		title=e.getTitle();
		writer=e.getWriter();
		readCount=e.getReadCount();
		updatedDate=e.getUpdatedDate();
				
	}
	


}
