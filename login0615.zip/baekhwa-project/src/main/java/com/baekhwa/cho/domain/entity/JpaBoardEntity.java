package com.baekhwa.cho.domain.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.stereotype.Service;

import com.baekhwa.cho.domain.dto.jpa.JpaBoardInsertDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor //DB에서 데이터 결과를 매핑하기 위해서 필요합니다.
@EntityListeners(AuditingEntityListener.class)
@Entity
@ToString
public class JpaBoardEntity { //jpa_board_entity
	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	private long no ;
	
	
	@Column(nullable = false)
	private String title;
	@Column(columnDefinition = "text not null") //데이터 범위가 더 좋은 text타입으로 설정해주는것
	private String content;
	@Column(nullable = false)
	private String writer;
	private int readCount;
	
	@CreationTimestamp 
	private LocalDateTime createdDate;

	@UpdateTimestamp
	private LocalDateTime updatedDate;
	

}
