package com.baekhwa.cho.domain.entity;

import org.springframework.data.jpa.repository.JpaRepository;

public interface JpaBoardEntityRepository extends JpaRepository<JpaBoardEntity, Long> {

}
