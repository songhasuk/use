package com.baekhwa.cho.service;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.baekhwa.cho.domain.dto.jpa.JpaBoardInsertDTO;
public interface BoardJpaService {

	void save(JpaBoardInsertDTO dto);

	void list(Model model);

	void detail(long no, Model model);

}
