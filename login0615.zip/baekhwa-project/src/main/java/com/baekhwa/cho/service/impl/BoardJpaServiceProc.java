package com.baekhwa.cho.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.Vector;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.baekhwa.cho.domain.dto.jpa.JpaBoardDetailDTO;
import com.baekhwa.cho.domain.dto.jpa.JpaBoardInsertDTO;
import com.baekhwa.cho.domain.dto.jpa.JpaBoardListDTO;
import com.baekhwa.cho.domain.entity.JpaBoardEntity;
import com.baekhwa.cho.domain.entity.JpaBoardEntityRepository;
import com.baekhwa.cho.service.BoardJpaService;

@Service
public class BoardJpaServiceProc implements BoardJpaService {

	@Autowired
	JpaBoardEntityRepository repository;
	//JPA dao = DB에 접근하기 위해 필요한 것(repository)
	//mybatis dao = DB에 접근하기 위해 필요한 것(mapper)
	
	@Override
	public void save(JpaBoardInsertDTO dto) {
		
		
		
		repository.save(dto.toEntity());
		//매개변수로 보내줘서 데이터의 저장은 메소드로 변환된 Entity 클래스만 가능하다.
	}

	@Override
	public void list(Model model) {
//★		 List<JpaBoardListDTO> result = repository.findAll()  // List<JpaBoardListDTO>형태로 리턴
//				 						.stream() 			  // stream<JpaBoardListDTO>로 변환됨
//				 						.map(JpaBoardListDTO::new) //엔티티에서 가저온 데이터를 생성자를 통해서 dto객체에 매핑 
//				 						.collect(Collectors.toList());
		 //.map(e-> new JpaBoardListDTO(e))
		 
		
		 //★model.addAttribute("list", repository.findAll())
		 //★서버에서 → 페이지(뷰)로 넘겨줄때는 Entity → DTO로 매핑하여 이용하자
		 //★Entity테이플(DB)에 저장된 원본 데이터가 변경,삭제될 위험이 있으니까 DTO로 매핑해야된다. 
		
//	↑같은	 List<JpaBoardEntity> r = repository.findAll();
//		 List<JpaBoardListDTO> list = new Vector<>();   // Entity → DTOㅌㅌ
//		 for(JpaBoardEntity e: r) {
//			 JpaBoardListDTO dto = new JpaBoardListDTO(e);
//			 list.add(dto); 
		 
		 model.addAttribute("list", repository.findAll().stream().map(JpaBoardListDTO::new)
				 					.collect(Collectors.toList()));
		 
	}

	@Override
	public void detail(long no, Model model) {
//		Optional<JpaBoardDetailDTO> result = repository.findById(no)
//											 .map(new Function<JpaBoardEntity, JpaBoardDetailDTO>() {
//
//												@Override
//												public JpaBoardDetailDTO apply(JpaBoardEntity t) {
//													// TODO Auto-generated method stub
//													return null;
//												}
//											});
		
// Optional<JpaBoardDetailDTO> result = repository.findById(no).map((e)->{return new JpaBoardDetailDTO(e);});
// Optional<JpaBoardDetailDTO> result = repository.findById(no).map(e->new JpaBoardDetailDTO(e));

//		Optional<JpaBoardDetailDTO> result = repository.findById(no).map(JpaBoardDetailDTO::new);
//		 model.addAttribute("detail", result);
		 
		 
		 model.addAttribute("detail", repository.findById(no).map(JpaBoardDetailDTO::new).get());
		
	}

}
