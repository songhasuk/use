package com.baekhwa.song.domain.dto.movie;

import lombok.Data;

@Data
public class DailyBoxOfficeDto {
	BoxOfficeResult boxOfficeResult;

}
