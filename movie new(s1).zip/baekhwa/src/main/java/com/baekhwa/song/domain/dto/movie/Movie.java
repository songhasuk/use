package com.baekhwa.song.domain.dto.movie;

import lombok.Data;

@Data
public class Movie {
	String rnum;
	String rank;
	String rankInten;
	String rankOldAndNew;
	String movieCd;
	String movieNm;
	String openDt;
	String salesAmt;
	String salesShare;
	String salesInten;
	String salesChange;
	String salesAcc;
	String audiCnt;
	String audiInten;
	String audiChange;
	String audiAcc;
	String scrnCnt;
	String showCnt;
}
