package com.baekhwa.song.domain.dto.visual;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
public class VisualUpdateDto {
	
	private String title;
	private String sub;
	private String link;

}
