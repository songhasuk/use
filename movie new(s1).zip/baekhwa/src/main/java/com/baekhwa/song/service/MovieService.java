package com.baekhwa.song.service;

import org.springframework.web.servlet.ModelAndView;

public interface MovieService {

	ModelAndView dailyBoxOffice();

}
