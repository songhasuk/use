package com.movie.test.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.movie.test.domain.dto.SignupDataDTO;
import com.movie.test.service.LonginService;



@Controller
public class LoginController {
	
	
	

	
	
	/////////////////////////페이지 이동
	
	//페이지 이동
	@GetMapping("/signup")
	public String signupPage() {
		
		return "login/signup";
	}
	@GetMapping("/signin")
	public String signinPage() {
		return "login/signin"; 
	}
	@GetMapping("/mem/mypage")
	public String myPage() {
		return "login/mypage"; 
	}
	@GetMapping("/mem/memberedit")
	public String editPage() {
		return "login/memberedit"; 
	}
	
	////////////////////////////////////비즈니스 로직
	
	@Autowired
	private LonginService service ;
	
	@PostMapping("/common/signup")
	public String signup(SignupDataDTO dto, HttpServletRequest request) {
		System.out.println(dto);
		
		return service.save(dto, request);
	}
	
//	@PostMapping("/login/signin")
//	public String signin(SignupDataDTO dto, Model model, HttpSession session) {
//		return service.log(dto, model, session);
//	}
//	

	
}
