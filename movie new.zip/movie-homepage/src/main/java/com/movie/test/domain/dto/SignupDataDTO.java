package com.movie.test.domain.dto;

import javax.persistence.Column;

import org.springframework.security.crypto.password.PasswordEncoder;


import com.movie.test.domain.entity.Member;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@ToString
@Setter
@Data
public class SignupDataDTO {
	
	private String email;
	private String pass;
	private String passCheck;
	private String userIp;
	
	private String nickName;
	
	
	public SignupDataDTO passEncode(PasswordEncoder pe) { // 비밀번호 엄호화
		this.pass=pe.encode(pass);
		return this;
	}
	
	public Member toEntity() {
		return Member.builder()
				.email(email).pass(pass).nickName(nickName).userIp(userIp)
				.build();
	}
	
	

}
