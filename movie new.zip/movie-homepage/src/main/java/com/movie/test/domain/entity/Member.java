package com.movie.test.domain.entity;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.movie.test.security.MemberRole;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

//@DynamicInsert
//@DynamicUpdate
//@Builder
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EntityListeners(AuditingEntityListener.class)
@Entity
public class Member {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long no;
	
	@Column(nullable = false, unique = true)
	private String email;
	@Column(nullable = false)
	private String pass;
	@Column(nullable = false)
	private String nickName;
	@Column(nullable = false)
	private String userIp;
	
	@CreationTimestamp
	private LocalDateTime createdDate;
	@UpdateTimestamp
	private LocalDateTime updatedDate;	
	
	
	@Builder.Default
	@Enumerated(EnumType.STRING)//DB에 저장시 문자열로 저장할때 적용 	
	@ElementCollection(fetch = FetchType.EAGER)  //컬렉션 형식의 테이블을 만들어준다는 어노테이션
	private Set<MemberRole> roleSet = new HashSet<MemberRole>();
	
	
	
	public Member addRole(MemberRole role) { //권한 생성 메소드
		roleSet.add(role);
		return this;
	}
	public Member removeRole(MemberRole role) { //권한 제거 메소드
		roleSet.remove(role);
		return this;
	}

}
