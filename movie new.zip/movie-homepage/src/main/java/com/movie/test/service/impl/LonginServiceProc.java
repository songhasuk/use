package com.movie.test.service.impl;



import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.movie.test.domain.dto.MemberDataDTO;
import com.movie.test.domain.dto.SignupDataDTO;
import com.movie.test.domain.entity.Member;
import com.movie.test.domain.entity.MemberRepository;import com.movie.test.security.MemberRole;
import com.movie.test.service.LonginService;


import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class LonginServiceProc implements LonginService {

	@Autowired
	private MemberRepository repository;
	
	@Autowired
	private PasswordEncoder pe;
	
	@Override
	public String save(SignupDataDTO dto, HttpServletRequest request) {
	
		dto.setUserIp(request.getRemoteAddr());
		
		int cnt = repository.findByEmail(dto.getEmail()).stream().map(MemberDataDTO::new).collect(Collectors.toList()).size();
		
	
		if(cnt > 0) {
		
			request.setAttribute("errorData", "이메일"+dto.getEmail()+"은 이미 가입되어있습니다.");
			return "login/signup";
		}
		else if(!dto.getPass().equals(dto.getPassCheck())) {

			request.setAttribute("errorData", "비밀번호가 서로 상이합니다.");
			return "login/signup";	
		}
		else {
			dto.passEncode(pe);
			
			repository.save(dto.toEntity().addRole(MemberRole.USER));			
			log.debug("저장완료");
			request.setAttribute("logData", dto.getNickName()+"님 회원가입이 완료되었습니다.");
			return "redirect:/";	
		}
	}
	
}
