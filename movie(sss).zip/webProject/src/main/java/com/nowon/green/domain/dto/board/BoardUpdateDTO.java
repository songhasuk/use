package com.nowon.green.domain.dto.board;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BoardUpdateDTO {

	private String title;
	private String content;
}
