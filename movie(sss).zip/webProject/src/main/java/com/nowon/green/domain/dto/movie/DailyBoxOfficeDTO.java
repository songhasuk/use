package com.nowon.green.domain.dto.movie;

import lombok.Data;

@Data
public class DailyBoxOfficeDTO {
	
	BoxOfficeResult boxOfficeResult;
}
