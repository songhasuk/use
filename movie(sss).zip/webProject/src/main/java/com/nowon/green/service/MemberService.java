package com.nowon.green.service;

import com.nowon.green.domain.dto.MemberInsertDTO;

public interface MemberService {

	void save(MemberInsertDTO dto);

}
