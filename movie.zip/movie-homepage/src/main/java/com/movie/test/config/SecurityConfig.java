package com.movie.test.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

@Configuration
public class SecurityConfig {
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
		
	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		http
			.authorizeRequests(authorize -> 
			authorize
				.antMatchers("/","/common/**").permitAll()
				.anyRequest().authenticated()
			);
		
		///로그인페이지 설정
		http.formLogin(formLogin ->
			formLogin
				.loginPage("/signin")//get 로그인페이지이동 url
				.usernameParameter("email")
				.passwordParameter("pass") 
				//.failureUrl("/login?error")
				.loginProcessingUrl("/login")//form action post Security가 처리해주는 url -> CustomUserDetailsService.java 코드로 자동으로 실행
				.defaultSuccessUrl("/", true)
				//.successHandler(null)
				//.failureHandler(null)
				.permitAll()
		);
		
		http.csrf();
			
		return http.build();
	}
	
	
	@Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return (web) -> web.ignoring().antMatchers(
        		"/css/**"
        		,"/js/**"
        		,"/images/**"
        		,"/favicon.ico*"
        		);
    }
	
	
	
}
