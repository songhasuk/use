package com.movie.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieHomepageApplicationTests {

	@Test
	void contextLoads() {
	}

}
