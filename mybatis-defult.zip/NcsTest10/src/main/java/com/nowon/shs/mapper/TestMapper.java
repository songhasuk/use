package com.nowon.shs.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.nowon.shs.dto.NCSDTO;

@Mapper
public interface TestMapper {

	

	List<NCSDTO> fainall();

	void save(NCSDTO build);

}
