package ncs12.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import ncs12.domain.dto.MemberLogDto;
import ncs12.domain.dto.memberDto;
import ncs12.service.MemverService;
import ncs12.service.impl.MemverServiceImpl;

@Controller
@RequestMapping("/mem/*")
public class MemberController {

	@Autowired
	private MemverService memverService;
	
	@PostMapping("/mem/reg")
	public String reg(memberDto dto, Model model) {
		
		
		memverService.save(dto, model);
		
		return "member/login"; // templates 경로
	}
	
	@PostMapping("/mem/login")
	public String login(memberDto dto, HttpSession session, Model model) {
		
		return  memverService.findById(dto, session, model); // templates 경로
	}
	
	@GetMapping("/mem/logout")
	public String logout(HttpSession session) {
		session.removeAttribute("logInfo");	
		return "redirect:/";
	}
}
