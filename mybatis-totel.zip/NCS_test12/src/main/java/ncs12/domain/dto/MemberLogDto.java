package ncs12.domain.dto;

import lombok.Data;



@Data
public class MemberLogDto {
	
	private String id;
	private	String pw;
}
