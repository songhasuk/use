package ncs12.mapper;

import java.util.List;
import java.util.Optional;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import ncs12.domain.dto.memberDto;

@Mapper
public interface TestMapper {

	void save(memberDto dto);

	

	Optional<memberDto> logCherk(String id);

	


}
