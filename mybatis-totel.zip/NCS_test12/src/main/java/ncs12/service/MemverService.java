package ncs12.service;

import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

import ncs12.domain.dto.memberDto;

public interface MemverService {

	
	void save(memberDto dto, Model model);

	String findById(memberDto dto, HttpSession session, Model model);


	

	

	

}
