package ncs12.service.impl;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;



import ncs12.domain.dto.MemberLogDto;
import ncs12.domain.dto.memberDto;
import ncs12.mapper.TestMapper;
import ncs12.service.MemverService;

@Service
public class MemverServiceImpl implements MemverService {

	private TestMapper testMapper;

	
	@Override
	public void save(memberDto dto, Model model) {
		
		model.addAttribute("success", dto.getName()+"님! 회원가입을 축하합나다.");
		testMapper.save(dto);

	}


	@Override
	public String findById(memberDto dto, HttpSession session, Model model) {
			String error;
		
		Optional<memberDto> result = testMapper.logCherk(dto.getId());
		
		if(result.isPresent()) {
			memberDto member = result.get();
			
			if(member.getPw().equals(dto.getPw())) {
				error=member.getName();
				session.setAttribute("loginfo", member);
				model.addAttribute("error", error);
				return  "redirect:/";
			}
		}
	
	error= "회원이 아니거나 이미 탈퇴한 회원입니다.";
	model.addAttribute("error", error);
	return "member/login";

	}
	
	
}
