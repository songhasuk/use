--table
CREATE TABLE ncstest12 
(
  no int PRIMARY KEY  auto_increment
, id VARCHAR2(255) NOT NULL
, pw VARCHAR2(255) NOT NULL
, name VARCHAR2(255) NOT NULL 
, created_date TIMESTAMP 

);
