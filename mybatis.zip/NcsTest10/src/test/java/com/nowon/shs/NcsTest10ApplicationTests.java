package com.nowon.shs;

import java.util.List;
import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.nowon.shs.dto.NCSDTO;
import com.nowon.shs.mapper.TestMapper;

@SpringBootTest
class NcsTest10ApplicationTests {
	@Autowired
	TestMapper testmappar;

	//@Test
	void 데이터삽입() {
		IntStream.rangeClosed(1, 10).forEach(i ->{
			testmappar.save(NCSDTO.builder().name("안녕하세요+"+i).build());
		});
		
		
	}
	
	//@Test
	void 데이터출력() {
		
		//List<NCSDTO> result = testmappar.fainall();
		testmappar.fainall().forEach(System.out::println);
	
	}
	
	
}
