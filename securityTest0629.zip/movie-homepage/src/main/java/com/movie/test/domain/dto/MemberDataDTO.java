package com.movie.test.domain.dto;

import java.time.LocalDateTime;

import com.movie.test.domain.entity.Member;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter

public class MemberDataDTO {
	
	
	private long no;
	private String email;
	private String pass;
	private String nickName;
	private LocalDateTime createdDate;
	private LocalDateTime updatedDate;
	
	public MemberDataDTO(Member m) {
		this.no=m.getNo();
		this.email=m.getEmail();
		this.pass=m.getPass();	
		this.nickName=m.getNickName();
		this.createdDate=m.getCreatedDate();
		this.updatedDate=m.getUpdatedDate();
	}


}
