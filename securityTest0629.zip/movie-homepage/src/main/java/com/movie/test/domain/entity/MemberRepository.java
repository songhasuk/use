package com.movie.test.domain.entity;


import java.util.Collection;
import java.util.List;
import java.util.Optional;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.movie.test.domain.dto.MemberDataDTO;



@Repository
public interface MemberRepository extends JpaRepository<Member, Long> {

	List<Member> findByEmail(String email);

	

	List<Member> findByEmailAndPass(String email, String pass);

	
	
	




	



}
