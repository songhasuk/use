package com.movie.test.service;

import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

import com.movie.test.domain.dto.SignupDataDTO;

public interface LonginService {

	String save(SignupDataDTO dto, Model model);

	String log(SignupDataDTO dto, Model model, HttpSession session);

}
