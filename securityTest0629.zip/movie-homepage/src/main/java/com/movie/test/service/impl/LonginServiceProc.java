package com.movie.test.service.impl;



import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.movie.test.domain.dto.MemberDataDTO;
import com.movie.test.domain.dto.SignupDataDTO;
import com.movie.test.domain.entity.Member;
import com.movie.test.domain.entity.MemberRepository;
import com.movie.test.service.LonginService;


import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class LonginServiceProc implements LonginService {

	@Autowired
	MemberRepository repository;
	
	@Override
	public String save(SignupDataDTO dto, Model model) {
		


		int cnt = repository.findByEmail(dto.getEmail()).size();
		
	
		if(cnt > 0) {
			model.addAttribute("errorData", "이메일"+dto.getEmail()+"은 이미 가입되어있습니다.");
			return "login/signup";
		}
		else if(!dto.getPass().equals(dto.getPassCheck())) {

			model.addAttribute("errorData", "비밀번호가 서로 상이합니다.");
			return "login/signup";	
		}
		else {
			repository.save(dto.toEntity());			
			log.debug("저장완료");
			model.addAttribute("logData", dto.getNickName()+"님 회원가입이 완료되었습니다.");
			return "redirect:/";	
		}
	}
		

	


	@Override
	public String log(SignupDataDTO dto, Model model, HttpSession session) {
		
		int cnt = repository.findByEmailAndPass(dto.getEmail(), dto.getPass()).size();
		System.out.println(cnt);
		
		if(cnt > 0) {
			List<MemberDataDTO> result = repository.findByEmailAndPass(dto.getEmail(), dto.getPass()).stream().map(MemberDataDTO::new).collect(Collectors.toList());
			session.setAttribute("logInfo", result);
			model.addAttribute("logData", result);
			return "redirect:/";
			
		}else {
			model.addAttribute("errorData", "비밀번호 혹은 존재하지 않는 회원입니다.");
			return "login/signin";	
		}
 		
		
	}




	
	

}
