package com.green.nowon.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfiguration {
	//Spring Security (스프링 시큐리티)
	//보안 : 인증(Authentication),권한(Authorization-인가,허가), Role-

	@Bean
	public PasswordEncoder passwordEncoder() { // 비빌번호 암호화 메소드 
		return new BCryptPasswordEncoder(16);
		//BCryptPasswordEncoder를 사용해서 비밀번호를 인코딩해주는 메서드와 
		//사용자의 의해 제출된 비밀번호와 저장소에 저장되어 있는 비밀번호의 일치 여부를 확인해주는 메서드를 제공합니다.
		
	}
 
	// SecurityFilterChain은 
	//보유 중인 권한(user 권한)으로 접근 권한을 확인하여 해당 페이지의 접근 권한(admin 권한)이 부여해주고,
	// 권한이 없으면 AuthorityChangeFilter를 호출하지 않고 403 오류를 냅니다.

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests((authz) -> 
            		authz
            		.antMatchers("/", "/board/list").permitAll()// 인증필요없이 누구나 접근가능
            		.antMatchers("/board/write").hasRole("USER") //회원
            		.antMatchers("/admin/**", "/board/write").hasRole("ADMIN") //관리자
            		.anyRequest().authenticated()
            		//위에 지정한 것을 제회한 나머지 URL요청은 모두 인증하고 접근하여야합니다.
            		//:로그인해야 접속 가능하다는 것, 그래서 permitAll()로 인증,권한이 필요없는 프리 페이지를 따로 지정해야됨 
            		
            		);
       http
       		.formLogin(form -> form  //보안 검증을 forMLogin 방식으로 하겠다
       					.loginPage("/signin")
       					.loginProcessingUrl("/signin")//loginProcessingUrl: form action
       					.usernameParameter("email") //Defaultis "username".
       					.passwordParameter("pass") //Defaultis "password".
       					.permitAll());  //누구나 접근할수 있다는 코드
            ;  //로그인 코드
       http.csrf().disable();     
        
        
        return http.build();
    }
    
    

	@Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return (web) -> web.ignoring().antMatchers(
        		"/css/**"
        		,"/js/**"
        		,"/images/**"
        		,"/favicon.ico*"
        		);
    }

}
