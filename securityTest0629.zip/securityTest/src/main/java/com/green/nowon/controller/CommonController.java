package com.green.nowon.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CommonController {

	@GetMapping("/signin")
	public String signin() {
		return "sign/signin";
	}
	@GetMapping("board/list") //아무나
	public void list() {}
	@GetMapping("board/write")
	public void write() {}
	
	@GetMapping("admin/admin")
	public void admin() {}
	
	
	//url 매핑주소  board/write  = templates:의 리턴 할 물리경로랑 동일한 경우 
	//void로 메소드 선언해 따로 물리경로를 지정해 리턴할 필요가 없어진다.
}


