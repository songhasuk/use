package com.green.nowon;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.green.nowon.domain.entity.Member;
import com.green.nowon.domain.entity.MemberRepository;
import com.green.nowon.security.MemberRole;

@SpringBootTest
class SecurityTestApplicationTests {

	@Autowired
	MemberRepository re;
	
	@Autowired
	PasswordEncoder en;
	
	//@Test
	void 관리자생성() {
		
		re.save(Member.builder()
				.email("admin@test.com")
				.pass(en.encode("1111"))
				.name("관리자")
				.build().addMemberRole(MemberRole.ADMIN).addMemberRole(MemberRole.USER) );
	}
	
	//@Test
	void 사용자생성() {
		
		re.save(Member.builder()
				.email("test01@test.com")
				.pass(en.encode("1111"))
				.name("테스트01")
				.build().addMemberRole(MemberRole.USER) );
	}

}
