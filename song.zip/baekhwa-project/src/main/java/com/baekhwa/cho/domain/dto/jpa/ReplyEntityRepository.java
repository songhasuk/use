package com.baekhwa.cho.domain.dto.jpa;

public class ReplyEntityRepository {

}
