package com.baekhwa.cho.domain.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Entity
public class Cart {

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	private long cartNo;
	
	private int orderPrice;
	private int count;

	//FK : orderNo
	@JoinColumn(name = "orderNo", nullable = false)
	@ManyToOne(cascade= CascadeType.PERSIST)//cascade, fatch:즉시로딩이 기본
	private Orders orders;
	
	@JoinColumn(name = "itemNo", nullable = false)
	@ManyToOne(cascade= CascadeType.DETACH)
	private Item item;
}

