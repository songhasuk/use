/*
 * package com.baekhwa.cho.domain.entity;
 * 
 * import java.util.List; import java.util.Vector;
 * 
 * import javax.persistence.Column; import javax.persistence.Entity; import
 * javax.persistence.FetchType; import javax.persistence.GeneratedValue; import
 * javax.persistence.GenerationType; import javax.persistence.Id; import
 * javax.persistence.JoinColumn; import javax.persistence.JoinTable; import
 * javax.persistence.ManyToMany;
 * 
 * import lombok.AllArgsConstructor; import lombok.Builder; import
 * lombok.Getter; import lombok.NoArgsConstructor; import lombok.ToString;
 * 
 * @ToString(exclude = "categorys")
 * 
 * @Builder
 * 
 * @AllArgsConstructor
 * 
 * @NoArgsConstructor
 * 
 * @Getter
 * 
 * @Entity public class Item2 {
 * 
 * @GeneratedValue(strategy = GenerationType.IDENTITY)
 * 
 * @Id private long itemNo;
 * 
 * @Column(nullable = false) private String name;
 * 
 * @Column(nullable = false) private int price;
 * 
 * @Column(nullable = false) private int stock;
 * 
 * //다대다 연결관계설정 //연계테이블 생성(식별관계)
 * 
 * @JoinTable( name = "CategoryItem", joinColumns = @JoinColumn(name="itemNo"),
 * inverseJoinColumns = @JoinColumn(name="categoryNo") )
 * 
 * @ManyToMany(fetch = FetchType.EAGER)
 * 
 * @Builder.Default private List<Category> categorys=new Vector<Category>();
 * //편의 메서드 public Item2 addCategory(Category category) {
 * categorys.add(category); return this; } public Item2 removeCategory(Category
 * category) { categorys.remove(category); return this; } }
 */
