package com.baekhwa.cho.domain.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Entity
public class Member {

	@Column(name = "no")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private long memberNo;

	
	@Column(nullable = false, unique = true)
	private String email;
	
	@Column(nullable = false)
	private String name;
	
	@Column(nullable = false)
	private String pass;
	
	@CreationTimestamp
	private LocalDateTime createdDate;
	@UpdateTimestamp
	private LocalDateTime updatedDate;
	
	//양항향인경우 그냥쓰면 연관테이블생성이되므로
	//속성을이용하다 : mappedBy = 주엔티티의 객체변수(필드명)
	@OneToMany(mappedBy = "member")//readOnly,(fetch = FetchType.LAZY)
	@Builder.Default
	List<Orders> orders=new ArrayList<Orders>();
	
	@Builder.Default
	@OneToMany(mappedBy = "member")
	List<JpaBoardEntity> boards=new ArrayList<JpaBoardEntity>();
	
}
