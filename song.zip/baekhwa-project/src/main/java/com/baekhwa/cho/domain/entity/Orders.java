package com.baekhwa.cho.domain.entity;

import java.util.List;
import java.util.Vector;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Entity
public class Orders {
	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	private long orderNo;
	@Column(nullable = false)
	private String status;

	//FK컬럼생성
	@JoinColumn(name = "memberNo", nullable = false)
	@ManyToOne//(fetch = fetchType.EAGER)
	private Member member;
	
	public Orders member(Member member) {
		this.member=member;
		return this;
	}
	@Builder.Default
	@OneToMany(mappedBy = "orders")
	private List<Cart> carts=new Vector<Cart>();
}
