package com.movie.test.service.impl;



import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.movie.test.domain.dto.MemberDataDTO;
import com.movie.test.domain.dto.SignupDataDTO;
import com.movie.test.domain.entity.Member;
import com.movie.test.domain.entity.MemberRepository;
import com.movie.test.service.LonginService;


import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class LonginServiceProc implements LonginService {

	@Autowired
	MemberRepository repository;
	
	@Override
	public String save(SignupDataDTO dto, Model model) {
		
		
		List<MemberDataDTO> result = repository.findByEmail(dto.getEmail())
				.stream().map(MemberDataDTO::new).collect(Collectors.toList());
		
		if(dto.getPass().equals(dto.getPassCheck())) {
		
			repository.save(dto.toEntity());			
			log.debug("저장완료");
			model.addAttribute("logData", dto.getNickName()+"님 정상적으로 회원가입되었습니다.");
			return "redirect:/";
		}


		if(dto.getEmail().equals(result.get(0).getEmail())) {
			model.addAttribute("errorData", "이메일"+dto.getEmail()+"은 이미 가입되어있습니다.");
			return "login/signup";
		}
	
		model.addAttribute("errorData", "비밀번호가 서로 상이합니다.");
		return "login/signup";
	
	
		
	}
	


	@Override
	public String log(SignupDataDTO dto, Model model, HttpSession session) {
		
		List<MemberDataDTO> result = repository.findByEmail(dto.getEmail())
				.stream().map(MemberDataDTO::new).collect(Collectors.toList());
		
		
		return null;
	}




	
	

}
