package com.baekhwa.song.service;

public interface MailService {
	
	public long mailSend(String email);
	
	//public String mailCheck(MailRequestDto dto);

}
