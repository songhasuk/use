package com.baekhwa.cho.domain.entity;

import java.util.List;
import java.util.Vector;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString(exclude = "categories")
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Entity
public class Item {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long itemNo;
	@Column(nullable = false)
	private String pname;
	@Column(nullable = false)
	private int price;
	@Column(nullable = false)
	private int stock;
	
	//다대다 연결관계설정
	//연계테이블 (식별관계)
	@JoinTable(
			name="category_item",
			joinColumns = @JoinColumn(name="itemNo"),
			inverseJoinColumns = @JoinColumn(name="categoryNo")
			)
	@ManyToMany(fetch = FetchType.EAGER)
	@Builder.Default
	private List<Category> categories= new Vector<Category>(); //
	
	//편의 메서드
	public Item addCategory(Category category) {
		categories.add(category);
		return this;
	}
	public Item removeCategory(Category category) {
		categories.remove(category);
		return this;
	}
	
	@OneToMany(mappedBy = "item")
	List<Order_item> orderItems; 
	
	
}
