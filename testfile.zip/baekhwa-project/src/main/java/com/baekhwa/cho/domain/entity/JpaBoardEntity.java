package com.baekhwa.cho.domain.entity;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Vector;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import org.apache.ibatis.type.Alias;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.baekhwa.cho.domain.dto.jpa.JpaBoardInsertDTO;
import com.baekhwa.cho.domain.dto.jpa.JpaBoardUpdateDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

//@ToString //함부로 쓰면 loop. 안끝남 알고쓰자
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@EntityListeners(AuditingEntityListener.class)
@Entity
//데이터가 변경될수도 있기때문에 일부러 setter만들지 않음 entity를dto에 카피해서 가져가야 안전 그게바로 mapping
public class JpaBoardEntity {//jpa_board_entity
											//auto도 있는데 걘 공용으로 쓰고 얜 여기에만
	@GeneratedValue(strategy = GenerationType.IDENTITY)//auto_increment
	@Id
	private long no;
	
	@Column(nullable = false) //not null
	private String title;
	@Column(columnDefinition = "text not null") //text: oracle-CLOB
	private String content;
	@Column(nullable = false)
	private String writer;
	private int readCount;
	
	@CreationTimestamp //EnableJpaAuditing 같은거 안 해줘도
	private LocalDateTime createdDate;
	@UpdateTimestamp //EnableJpaAuditing 같은거 안 해줘도
	private LocalDateTime updatedDate;

	//@EnableJpaAuditing:-> @CreatedDate @LastModifiedDate
	//jpa를 상속받아서 처리하는애 :hibernate
	
	@Builder.Default
	@JoinColumn(name= "bno")
	@OneToMany(cascade= CascadeType.ALL, fetch= FetchType.LAZY)
//	@OneToMany(mappedBy="jpaBoardEntity",cascade= CascadeType.ALL )
	private Collection<ReplyEntity> replies = new Vector<ReplyEntity>();
	
	//replies 등록 메서드
	public JpaBoardEntity addReply(ReplyEntity e) {
		replies.add(e);
		return this;
	}
	
	//수정처리하기 위한 메서드
	public JpaBoardEntity update(JpaBoardUpdateDTO dto) {
		
		this.title=dto.getTitle();
		this.content=dto.getContent();
		return this;
	}
}