package com.baekhwa.cho.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Entity(name="orderItem")
public class Order_item {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long orderItemNo;
	@Column(nullable = false)
	private int orderPrice;
	@Column(nullable = false)
	private int count;
	
	@ManyToOne
	@JoinColumn(name="orderNo" , nullable = false)
	private Orders orders;
	
	@ManyToOne
	@JoinColumn(name="itemNo" , nullable = false)
	private Item item;
}
