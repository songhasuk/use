package com.baekhwa.cho.domain.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Entity(name="orders")   //외래키[FK]가 설정되는(가지는) 테이블에만 따로 테이블명르 지정해줘야된다. (why:불필요한 조인테이블이 자동생성되는걸 방지)
public class Orders {
	
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long orderNo;
	@Column(nullable = false)
	private String ostatus;
	
	@ManyToOne
	@JoinColumn(name="no" , nullable = false)  //외래키를 받아야되는 참조테이블 입장에서는 @JoinColumn써서 타테이블에서 받을 컬럼명을 써준다.
	private Member member;  //해당 테이블(member)의 입장을 표현하는 것을 쓴다.
	
	@OneToOne
	@JoinColumn(name="deliveryNo", nullable = false) 
	private Delivery delivery; //해당 테이블(Delivery)의 입장을 표현하는 것을 쓴다.
	
	
	@OneToMany(mappedBy = "orders")
	List<Order_item> OrderItems ;
	
	
	
}
