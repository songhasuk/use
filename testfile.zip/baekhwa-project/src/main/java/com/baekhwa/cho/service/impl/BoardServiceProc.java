package com.baekhwa.cho.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.baekhwa.cho.domain.dto.BoardDTO;
import com.baekhwa.cho.domain.dto.BoardInsertDTO;
import com.baekhwa.cho.domain.dto.BoardListDTO;
import com.baekhwa.cho.domain.dto.BoardUpdateDTO;
import com.baekhwa.cho.mybatis.mapper.BoardMapper;
import com.baekhwa.cho.service.BoardService;
import com.baekhwa.cho.util.PageInfo;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BoardServiceProc implements BoardService {
	
	//dao ???
	@Autowired
	private BoardMapper mapper;
	
	@Override
	public void boardListAll(Model model) {
		
		//List<BoardDTO> to List<BoardListDTO>
		List<BoardListDTO> result=mapper.findAll()
									.stream()
									.map(BoardListDTO::new)//BoardDTO-->BoardListDTO : BoardListDTO(BoardDTO)
									.collect(Collectors.toList());
		model.addAttribute("list", result);
		
	}
	@Override
	public void boardList(int pageNo, Model model) {
		int limit=10;
		int offset=limit *(pageNo-1);; //현실의 페이지는 offset의 0
		List<BoardListDTO> result = mapper.select(offset,limit);
		int rowTotal = mapper.selectCount();
		
		model.addAttribute("list", result);
		model.addAttribute("pi", PageInfo.getInstance(pageNo, rowTotal, limit));
	
	}

	
	@Override
	public void save(BoardInsertDTO dto) {
		//DB save : who? : dao
		int n=mapper.save(dto);
		//n db에서 변경된 데이터 정보 리턴
	}
	
	//상세정보 불러와서 모델에 담기
	@Override
	public void detail(int no, Model model) {
		//필요한걸 생각해서 dto 정보 전체가 필요
		//null point exception이 발생할 여지를 방지하기 위해 optional사용
		BoardDTO result = mapper.findById(no).orElseThrow();
		//조회수 update
		mapper.updateReadCount(no);
		model.addAttribute("detail",result);
	}
	
	@Override
	public void update(BoardUpdateDTO dto) {
		int n= mapper.update(dto);
		log.debug(n+"개의 데이터 수정완료!");
	}

	@Override
	public void delete(int no) {
		mapper.deleteById(no);
	}
	

}
