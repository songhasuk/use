package com.baekhwa.cho;

import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.baekhwa.cho.domain.dto.BoardInsertDTO;
import com.baekhwa.cho.domain.dto.MemberDTO;
import com.baekhwa.cho.domain.dto.MemberInsertDTO;
import com.baekhwa.cho.domain.dto.MemberUpdateDTO;
import com.baekhwa.cho.domain.dto.jpa.JpaBoardInsertDTO;
import com.baekhwa.cho.domain.entity.Category;
import com.baekhwa.cho.domain.entity.CategoryRepository;
import com.baekhwa.cho.domain.entity.Item;
import com.baekhwa.cho.domain.entity.ItemRepository;
import com.baekhwa.cho.mybatis.mapper.BoardMapper;
import com.baekhwa.cho.mybatis.mapper.MemberMapper;
import com.baekhwa.cho.service.BoardJpaService;

@SpringBootTest
class BaekhwaProjectApplicationTests {

	@Autowired
	MemberMapper mapper;

	@Autowired
	BoardMapper boardMapper;
	//////////////////

	// @Test
	void 더미데이터() {
		IntStream.rangeClosed(1, 200).forEach(i -> {
			boardMapper.save(BoardInsertDTO.builder().title("제목" + i).content("내용" + i).writer("shs1995").build());
		});
	}

	// @Test
	void 멤버삽입테스트() {
		int r = mapper.save(MemberInsertDTO.builder().email("test02@test.com").name("test01").pass("1111").build());
		// update 된 rows 수 리턴
		System.out.println(r + "개의 회원정보를 삽입하였습니다.");
	}

	//
	// @Test
	void 비밀번호수정() {
		MemberUpdateDTO dto = MemberUpdateDTO.builder().no(2).pass("2222").build();
		// 먼저 대상이 존재하는지 체크
		Optional<MemberDTO> result = mapper.selectById(dto.getNo());
		if (result.isEmpty()) {
			System.out.println(">>>존재하지않는 회원");
			return;
		}

		mapper.update(dto);
	}

	///////////////////////////////////////////////////////
	@Autowired
	BoardJpaService service;

	// @Test
	void jpa데이터저장테스트() {
		IntStream.range(1, 100).forEach(i -> {

			JpaBoardInsertDTO dto = new JpaBoardInsertDTO();
			dto.setTitle("제목" + i);
			dto.setContent("내용" + i);
			dto.setWriter("test02@test.com");

			service.save(dto);

		});

	}

///////////////////////////////
	@Autowired
	CategoryRepository categoryRepository;

	//@Test
	void 카테고리등록_테스트() {
		categoryRepository.save(Category.builder().cname("가구").build());
	}

///////////////////////////
	@Autowired
	ItemRepository itemRepository;

	//@Test
	void 상품등록_테스트() {
//먼저 실행후 밑에거 실행
//		itemRepository.save(Item.builder().pname("사과").price(5000).stock(100).build()
//				.addCategory(Category.builder().categoryNo(1).build()));
		itemRepository.save(
				Item.builder().pname("친환경 능이버섯 1KG").price(29800).stock(10000).build()
				.addCategory(Category.builder().categoryNo(1).build())
				.addCategory(Category.builder().categoryNo(2).build()));

	}
	@Transactional
	//@Test
	void 해당카테고리_상품조회() {
//		categoryRepository.findByCname("식품").map(e -> e.getItems()).stream().map(e -> (Item) e)
//				.collect(Collectors.toList()).forEach(System.out::println);
		
		Category result = categoryRepository.findByCname("식품").orElseThrow();
		List<Item> items = result.getItems();
		for(Item t :items) {
			System.out.println(t);
		}
	}
	
	@Test
	void 상품테이블에서_카테고리를조건적용검색() {
		List<Item> result = itemRepository.findAllByCategoriesCategoryNo(1L);
		for(Item t :result) {
			System.out.println(t);
		}
	}
	

}
