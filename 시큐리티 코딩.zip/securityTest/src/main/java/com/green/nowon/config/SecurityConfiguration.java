package com.green.nowon.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfiguration {
	
	//보안 : 인증(Authentication),권한(Authorization-인가,허가), Role-
	
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder(16);
	}

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests((authz) -> 
            		authz
            		.antMatchers("/", "/board/list").permitAll()// 인증필요없이 누구나 접근가능
            		.antMatchers("/board/write").hasRole("USER") //회원
            		.antMatchers("/admin/**", "/board/write").hasRole("ADMIN") //관리자
            		.anyRequest().authenticated()//나머지 요청은 모두 인증하고 접근하여야합니다.:로그인하세요
            		);
       http
       		.formLogin(form -> form
       					.loginPage("/signin")
       					.loginProcessingUrl("/signin")//loginProcessingUrl: form action
       					.usernameParameter("email") //Defaultis "username".
       					.passwordParameter("pass") //Defaultis "password".
       					.permitAll());  //누구나 접근할수 있다는 코드
            ;  //로그인 코드
       http.csrf().disable();     
        
        
        return http.build();
    }
    
    

	@Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return (web) -> web.ignoring().antMatchers(
        		"/css/**"
        		,"/js/**"
        		,"/images/**"
        		,"/favicon.ico*"
        		);
    }

}
