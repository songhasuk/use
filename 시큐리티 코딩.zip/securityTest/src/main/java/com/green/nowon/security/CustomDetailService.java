package com.green.nowon.security;

import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.green.nowon.domain.entity.Member;
import com.green.nowon.domain.entity.MemberRepository;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class CustomDetailService implements UserDetailsService{
	
	private final MemberRepository repository;
	
	//DaoAuthenticationProvider

	//이메일(id) 를 이용하여 회원이 존재하는지 체크 존재하면 상세정보(UserDetails)
	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		System.out.println(">>>>>>"+email);
		
//		MemberRole roles=MemberRole.USER;
//		System.out.println(roles.name());
//		System.out.println(roles.ordinal());
//		System.out.println(roles.getTitle());
//		System.out.println("--------------");
//		role=MemberRole.ADMIN;
//		System.out.println(roles.name());
//		System.out.println(roles.ordinal());
//		System.out.println(roles.getTitle());
		Optional<Member> result=repository.findByEmail(email);
		if(result.isEmpty()) {
			throw new UsernameNotFoundException("회원이 존재하지 않아요");//예외발생
		}
		//예외 발생시 아래 코드는 실행 안됨
		//db에서 읽어들인 정보를 MyUserDetails 객체로 매핑

		Member entity=result.get();
		
		//DB에저장된 회원의 권한(ROLE)
//		Set<SimpleGrantedAuthority> roleSet= entity.getRoleSet().stream()
//											 .map(role->{return new SimpleGrantedAuthority("ROLE_"+role.name());})
//											 .collect(Collectors.toSet());
		return new MyUserDetails(entity.getEmail(), entity.getPass(), entity.getName(), entity.getRoleSet()
				.stream()
				.map(role->new SimpleGrantedAuthority(role.getRole()))
				.collect(Collectors.toSet()));
	}

}
