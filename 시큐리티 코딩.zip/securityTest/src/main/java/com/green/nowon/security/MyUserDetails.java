package com.green.nowon.security;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import lombok.Getter;

@Getter
public class MyUserDetails extends User{
	
	private String email;//User.username == email   //${#authentication.name}
	private String name;   							//${#authentication.principal.name}

	/**
	 * 
	 * @param username : 로그인시 입력한 eamil 
	 * @param password : 비밀번호
	 * @param name     : 이름
	 * @param authorities : 권한
	 */
	public MyUserDetails(String username, String password,String name, Collection<? extends GrantedAuthority> authorities) {
		super(username, password, authorities);
		email=username;
		this.name=name;
		
	}

	

}
